/** @type {import('tailwindcss').Config} */
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
  content: [
    "gamescreen.html",
    // other paths where Tailwind should look for classes to be purged
  ],
  theme: {
    extend: {
      colors: {
        'custom-purple': '#3f3cbb',
        'custom-pink': '#ec4899',
        // Define other custom colors here
      },
      borderRadius: {
        '4xl': '2rem',
        // other custom border radius
      },
      fontFamily: {
        'overpass': ['Overpass', 'sans-serif'],
        'cabin': ['Cabin', 'sans-serif'],
        'roboto-mono': ['Roboto Mono', 'monospace'],
        // other custom fonts
      },
      // Define other theme extensions here
    },
  },
  plugins: [
    // other plugins here
  ],
}


